package br.com.sousaingrid.actres

import android.app.Application
import java.lang.IllegalStateException

class PaisesApplication: Application() {
    override fun onCreate() {
        super.onCreate()
        appInstance = this
    }

    companion object {
        private var appInstance: PaisesApplication? = null

        fun getInstance(): PaisesApplication {
            if (appInstance == null){
                throw IllegalStateException("Configurar application")
            }
            return appInstance!!
        }
    }

}