package br.com.sousaingrid.actres

import com.google.gson.GsonBuilder
import java.io.Serializable



class Paises : Serializable {

        var id:Long = 0
        var nome = ""
        var ementa = ""
        var foto = ""
        var professor = ""

        override fun toString(): String {
            return "Paises(nome='$nome')"
        }

        fun toJson(): String {
            return GsonBuilder().create().toJson(this)
        }
    }
