package br.com.sousaingrid.actres

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class PaisesAdapter(
    val paises: List<Paises>,
    val onClick: (Paises) -> Unit
):RecyclerView.Adapter<PaisesAdapter.PaisesViewHolder>(){
   class PaisesViewHolder(view: View):
           RecyclerView.ViewHolder(view) {
       val cardNome: TextView
       val cardImg: ImageView
       val cardProgress: ProgressBar
       val cardView: CardView

       init {
           cardNome = view.findViewById(R.id.card_nome)
           cardImg = view.findViewById(R.id.card_img)
           cardProgress = view.findViewById(R.id.card_progress)
           cardView = view.findViewById(R.id.card_paises)
         }

   }

    override fun getItemCount() = this.paises.size

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int): PaisesViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.adapter_paises, parent,false)
        val holder = PaisesViewHolder(view)

        return holder
    }

    override fun onBindViewHolder(
        holder: PaisesViewHolder, position: Int) {

        val planeta = paises[position]

        holder.cardNome.text = planeta.nome
        holder.cardProgress.visibility = View.VISIBLE

        Picasso.with(holder.itemView.context)
            .load(planeta.foto)
            .into(holder.cardImg, object: com.squareup.picasso.Callback {
                override fun onSuccess() {
                    holder.cardProgress.visibility = View.GONE
                }

                override fun onError() {
                    holder.cardProgress.visibility = View.GONE
                }
            })


        holder.itemView.setOnClickListener{onClick(paises)}
    }

    private fun onClick(paises: List<Paises>) {

    }

}